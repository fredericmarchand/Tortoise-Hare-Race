Frederic Marchand
Comp2404 Assignment 1
The Tortoise Chronicles: Race up the Cliffs of Unsifficient Logic

Files submitted:

Makefile
Hare.h
Hare.cpp
Tortoise.h
Tortoise.cpp
Mountain.h
Mountain.cpp
Snack.h
Snack.cpp
Screen.h
Screen.cpp
Race.h
Race.cpp
main.h
main.cpp
random.h
random.o
UML.pdf
README.txt

Instructions
To compile and assemble call 'make' on the command line on any lambda machine
**Before running make your terminal window fullscreen**Although this is optional because the game will work with any size window**
to run call ./play on the command line

When the game has started the game ask you to press any key on your keyboard to start the race
When the race has ended, if you press the 'r' key the game will restart, any other key will exit the program
**Don't worry these instructions are in the program aswell**
