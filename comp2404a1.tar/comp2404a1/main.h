/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *  Frederic Marchand
 *  Comp2404 Assignment 1
 *  main.h
 *
 *  This is the header file for main.cpp
 *
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

using namespace std;

#include <ncurses.h>
#include "Race.h"


