#ifndef RANDOM_H
#define RANDOM_H

int randomInt(int max);
int randomInt(int min, int max);

#endif 
